﻿#pragma once
#include <memory>
#include <typeindex>
#include <unordered_map>
#include <vector>
#include <algorithm>

#include "handler.h"
#include "base/nx_pch.h"

namespace nx::event
{
    class handler_base;

    class event_system final
    {
    public:
        template <typename TMessage, typename TAgent>
        using message_callback = void(TAgent::*)(const TMessage&);
        template <typename TMessage, typename TAgent>
        using message_callback_const = void(TAgent::*)(const TMessage&) const;

        template <typename TMessage, typename TAgent>
        void subscribe(message_callback<TMessage, TAgent> callback_func, TAgent* instance)
        {
            const auto wrapper = new member_function_wrapper<TAgent, TMessage>(callback_func, instance);
            handlers_[std::type_index(typeid(TMessage))].push_back(std::unique_ptr<handler_base>(wrapper));
        }

        template <typename TMessage>
        void subscribe(void (*callback)(const TMessage&))
        {
            auto wrapper = new static_function_wrapper<TMessage>(callback);
            handlers_[std::type_index(typeid(TMessage))].push_back(std::unique_ptr<handler_base>(wrapper));
        }

        template <typename TMessage, typename TAgent>
        void subscribe(message_callback_const<TMessage, TAgent> callback_func_const, TAgent* instance)
        {
            const auto wrapper = new member_function_wrapper<TAgent, TMessage>(callback_func_const, instance);
            handlers_[std::type_index(typeid(TMessage))].push_back(std::unique_ptr<handler_base>(wrapper));
        }

        template <typename TMessage>
        void unsubscribe_all()
        {
            handlers_[std::type_index(typeid(TMessage))].clear();
        }
        void unsubscribe_all()
        {
            handlers_.clear();
        }

        template <typename TMessage, typename TAgent>
        void unsubscribe(message_callback<TMessage, TAgent> callback, const TAgent* instance)
        {
            auto& handlers = handlers_[std::type_index(typeid(TMessage))];
            const auto it = std::find_if(
                handlers.begin(), handlers.end(),
                [&](const std::unique_ptr<handler_base>& handler)
                {
                    auto wrapper = static_cast<member_function_wrapper<TAgent, TMessage>*>
                        (handler.get());
                    return wrapper->equals(callback, instance);
                });
            if (it != handlers.end())
            {
                handlers.erase(it);
            }
        }

        template <typename TMessage, typename TAgent>
        void unsubscribe(message_callback_const<TMessage, TAgent> callback_func_const, TAgent* instance)
        {
            auto& handlers = handlers_[std::type_index(typeid(TMessage))];
            const auto it = std::find_if(
                handlers.begin(), handlers.end(),
                [&](const std::unique_ptr<handler_base>& handler)
                {
                    auto wrapper = static_cast<member_function_wrapper<TAgent, TMessage>*>
                        (handler.get());
                    return wrapper->equals(callback_func_const, instance);
                });
            if (it != handlers.end())
            {
                handlers.erase(it);
            }
        }

        template <typename TMessage, typename TAgent>
        void unsubscribe(message_callback_const<TMessage, TAgent> callback_func_const, const TAgent* instance)
        {
            auto& handlers = handlers_[std::type_index(typeid(TMessage))];
            const auto it = std::find_if(
                handlers.begin(), handlers.end(),
                [&](const std::unique_ptr<handler_base>& handler)
                {
                    auto wrapper = static_cast<member_function_wrapper<TAgent, TMessage>*>
                        (handler.get());
                    return wrapper->equals(callback_func_const, instance);
                });
            if (it != handlers.end())
            {
                handlers.erase(it);
            }
        }

        template <typename TMessage>
        void publish(const TMessage& msg)
        {
            const auto type = std::type_index(typeid(TMessage));
            if (const auto it = handlers_.find(type); it != handlers_.end())
            {
                for (const auto& handler : it->second)
                {
                    handler->handle(&msg);
                }
            }
        }

    private:
        std::unordered_map<std::type_index, std::vector<std::unique_ptr<handler_base>>> handlers_;
    };
}